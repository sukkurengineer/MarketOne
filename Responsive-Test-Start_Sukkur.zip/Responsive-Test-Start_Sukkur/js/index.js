const validateForm = () => {
  // regex for email and phone number (Indian phonenumber)
  const regExp = new RegExp("[a-z0-9]+@[a-z]+.[a-z]{2,3}");
  const phoneRegex = /^[6-9]\d{9}$/gi;

  // id variables for input and label - this is for style control
  const fnameId = document.getElementById("fname");
  const fnameLableId = document.getElementById("fnameLab");
  const lnameId = document.getElementById("lname");
  const lnameLableId = document.getElementById("lnameLab");
  const titleId = document.getElementById("title");
  const titleLabelId = document.getElementById("titleLab");
  const emailId = document.getElementById("email");
  const emailLabelId = document.getElementById("emailLab");
  const phoneId = document.getElementById("phonenum");
  const phoneLabelId = document.getElementById("pLab");
  const clientId = document.getElementById("client");
  const clientLabelId = document.getElementById("clientLab");

  // this variables for getting value from form
  let firstName = document.forms["myForm"]["fname"].value;
  let lastName = document.forms["myForm"]["lname"].value;
  let litle = document.forms["myForm"]["title"].value;
  let email = document.forms["myForm"]["email"].value;
  let phone = document.forms["myForm"]["phone"].value;
  let client = document.forms["myForm"]["client"].value;

  if (firstName == "" || lastName == "" || litle == "" || email == "" || phone == "" || client == "") {
    if (firstName == "") {
      fnameId.style.borderColor = "red";
      fnameLableId.style.color = "red";
    }
    if (firstName !== "") {
      fnameId.style.borderColor = "gray";
      fnameLableId.style.color = "#333333";
    }
    if (lastName == "") {
      lnameId.style.borderColor = "red";
      lnameLableId.style.color = "red";
    }
    if (lastName !== "") {
      lnameId.style.borderColor = "gray";
      lnameLableId.style.color = "#333333";
    }
    if (litle == "") {
      titleId.style.borderColor = "red";
      titleLabelId.style.color = "red";
    }
    if (litle !== "") {
      titleId.style.borderColor = "gray";
      titleLabelId.style.color = "#333333";
    }
    if (email == "") {
      emailId.style.borderColor = "red";
      emailLabelId.style.color = "red";
    }
    if (email !== "") {
      if (regExp.test(email) == false) {
        emailId.style.borderColor = "red";
        emailLabelId.style.color = "red";
        return false;
      }
      emailId.style.borderColor = "gray";
      emailLabelId.style.color = "#333333";
    }
    if (phone == "") {
      phoneId.style.borderColor = "red";
      phoneLabelId.style.color = "red";
    }
    if (phone !== "") {
      if (phoneRegex.test(phone) == false) {
        phoneId.style.borderColor = "red";
        phoneLabelId.style.color = "red";
        return false;
      }
      phoneId.style.borderColor = "gray";
      phoneLabelId.style.color = "#333333";
    }
    if (client == "") {
      clientId.style.borderColor = "red";
      clientLabelId.style.color = "red";
    }
    if (client !== "") {
      clientId.style.borderColor = "gray";
      clientLabelId.style.color = "#333333";
    }
    return false;
  } else if (phoneRegex.test(phone) == false) {
    phoneId.style.borderColor = "red";
    phoneLabelId.style.color = "red";
    return false;
  } else if (regExp.test(email) == false) {
    emailId.style.borderColor = "red";
    emailLabelId.style.color = "red";
    return false;
  } else {
    alert(`
    User Name : ${firstName} ${lastName}
    Title : ${litle}
    Email : ${email}
    Phone Number : ${phone}
    Client : ${client}
    `);
    return true;
  }
}
